package com.example.pizza;

public class pizza {
    private String customername;
    private int mobilenumber;
    private String pizzasize;
    private int toppings;
    private int totalbill;


    public pizza(String customername, int mobilenumber, String pizzasize, int toppings, int totalbill) {
        this.mobilenumber = mobilenumber;
        this.customername = customername;
        this.pizzasize = pizzasize;
        this.toppings = toppings;
        this.totalbill = totalbill;
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public int getMobilenumber() {
        return mobilenumber;
    }

    public void setMobilenumber(int mobilenumber) {
        this.mobilenumber = mobilenumber;

    }

        public int getToppings() {
            return toppings;
        }

        public void setToppings(int toppings) {this.toppings = toppings;
        }

        public String getPizzasize() {
            return pizzasize;
        }

        public void setPizzasize(String pizzasize) {
            this.pizzasize = pizzasize;
        }
    public int getTotalbill() {
        return totalbill;
    }

    public void setTotalbill(int totalbill) {
        this.totalbill = totalbill;
    }
    }


